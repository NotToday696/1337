<?php
$link=mysqli_connect('31.31.196.240', 'u1307120_hack', 'qwertyuiop123', 'u1307120_hack');
mysqli_set_charset($link, 'utf8');
if (!$link) {
    die('Ошибка подключения (' . mysqli_connect_errno() . ')' . mysqli_connect_error());
}

echo 'Соединение установлено...'.mysqli_get_host_info($link)."\n";

?>

<?php
include 'simple_html_dom.php';
require_once 'simple_html_dom.php';
//for ($k=1;$k<=36;$k++) {
//    $u= (string) $k;
//    echo 'Страница '. $u. '</br>';


    $result = array();
    $data = file_get_html('https://fabricators.ru/proizvodstvo/zavody-stroitelnyh-materialov?page=');
    if ($data != '' && count($data->find('div [class=content-list-item enterprise-teaser] a'))) {
        $i = 0;
        foreach ($data->find('div [class=content-list-item enterprise-teaser] a') as $name) {
//            $insert = "INSERT INTO PROVIDERS (name, link) VALUES ('$name->plaintext','https://fabricators.ru$name->href')";
//            $res_insert = mysqli_query($link, $insert) or die(mysqli_error($link));
            $namee = $name->plaintext;
            $namee = mysqli_real_escape_string($link, $namee);

            $linkk = 'https://fabricators.ru' . $name->href;
            $linkk = mysqli_real_escape_string($link, $linkk);
            echo $linkk . '<br>';

            $result[$i]['name'] = $namee;
            $result[$i]['link'] = $linkk;

            $i++;
        }
    }
    if ($data!= '' && count($data->find('div [class=field-item even] p'))) {
        $i = 0;
        foreach ($data->find('div [class=field-item even] p') as $tr) {
//            $insert1="INSERT INTO PROVIDERS (description) VALUES ('$tr->plaintext')";
//            $res_insert1=mysqli_query($link, $insert1) or die(mysqli_error($link));
            $description = $tr->plaintext;
            $description = mysqli_real_escape_string($link, $description);

            $result[$i]['description'] = $description;
            $i++;
//            echo '<div href="https://fabricators.ru' . $tr->href . '">' . $tr->plaintext . '</div></br>';
////            file_put_contents('results.json', $data);

        }
    }
//    if ($data!= '' && count($data->find('div [class=content-list-item enterprise-teaser] p'))) {
//        $i = 0;
//        foreach ($data->find('div [class=content-list-item enterprise-teaser] p') as $tr) {
//            $region = $tr->plaintext;
//            $region = mysqli_real_escape_string($link, $region);
//            $result[$i]['region'] = $region;
//            $i++;
//          echo '<div href="https://fabricators.ru' . $tr->href . '">' . $tr->plaintext . '</div></br>';
//        }
//    }
//
//    if ($data!= '' && count($data->find('div [class=content-list-item__txt] p [class=text--col1]'))) {
//     $i = 0;
//        foreach ($data->find('div [class=content-list-item__txt] p [class=text--col1]') as $trr) {
//            $adress = $trr->plaintext;
//            $adress = mysqli_real_escape_string($link, $adress);
//            $result[$i]['adress'] = $adress;
//            $i++;
////            echo '<div href="https://fabricators.ru' . $tr->href . '">' . $tr->plaintext . '</div></br>';
//        }
//    }
require_once 'phpQuery.php';//подключаем библиотеку phpQuery
$url = 'https://fabricators.ru/proizvodstvo/zavody-stroitelnyh-materialov?page=1';//URL записи
$curl = curl_init();//инициализация запроса
curl_setopt($curl, CURLOPT_URL, $url);//сюда передаем URL нашей страницы
curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);//записывать в переменную, а не выводить
$result_pic = curl_exec($curl);//запрос и запись в переменную $result

$pq = phpQuery::newDocument($result_pic);//создается объект в котором весь код страницы

$elem = $pq->find("img")->attr('src');//поиск элемента
$ph = file_get_contents($elem);
$insert_pic= "INSERT INTO PROVIDERS (image) VALUES (" . $ph->href . ")";



print_r($result);

    foreach ($result as $row) {
        $query = "INSERT INTO PROVIDERS (name, link, description) VALUES ('" . $row['name'] . "', '" . $row['link'] . "', '" . $row['description'] . "')";
        echo $query . '<br>';
        mysqli_query($link, $query) or die(mysqli_error($link));
    }

    //$query = "INSERT INTO (name, link, description) VALUES ('" . $result['name'] . "', '" . $result['link'] . "', '" . $result['description'] . "')";



//}
?>