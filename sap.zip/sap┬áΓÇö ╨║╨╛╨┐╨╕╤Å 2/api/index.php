<?php

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Credentials: true");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Access-Control-Allow-Headers, Origin,Accept, X-Requested-With, Content-Type, Access-Control-Request-Method, Access-Control-Request-Headers");

require_once('connectDb.php');

$resultArray = array();
$query = json_decode(file_get_contents('php://input'), true);
$result = mysqli_query($link, $query);
if($result) {
  for($i=0; $i<mysqli_num_rows($result); $i++) {
    array_push($resultArray, mysqli_fetch_assoc($result));
  }
}

echo json_encode($resultArray);