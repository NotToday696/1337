export function renderSupplier({id, name, region, description, date}) {
  return `
    <div class="catalog__item">
      <h3 class="catalog__title" data-id="${id}" data-click="openSupplier">${name}</h3>
      <p class="catalog__subtitle">поставка материалов для строительства, ремонта и отделки</p>
      <p class="catalog__region">Россия, ${region}</p>
      <p class="catalog__desc">${description}</p>
      <div class="catalog__item-footer">
        <span>Дата добавления: ${date}</span>
        <div class="catalog__buttons">
          <button class="catalog__button button" data-id="${id}" data-click="toFavorite">❤️</button>
          <button class="catalog__button button" data-click="chat">Написать</button>
          <button class="catalog__button button" data-click="openSupplier">Подробнее</button>
        </div>
      </div>
    </div>
  `
}
