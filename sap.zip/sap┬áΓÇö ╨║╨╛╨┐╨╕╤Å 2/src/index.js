import './scss/style.scss'

import { renderSupplier } from './templates/supplier.template'

import logo from './assets/icon/logo.png'
import user from './assets/icon/user.svg'

const $main = document.getElementById('main')
const $supplier = document.getElementById('supplier')
const $sort = document.getElementById('sort')
const $info = document.getElementById('info')
const $infoHeader = document.getElementById('infoHeader')
const $catalog = document.getElementById('catalog')
const $catalogBack = document.getElementById('catalogBack')
const $chat = document.getElementById('chat')

document.querySelector('body').addEventListener('click', buttonsHandler)

renderSuppliers('SELECT * FROM PROVIDERS ORDER BY id DESC')

async function renderSuppliers(request) {
  const supplierData = await sendQuery(request)
  
  let html = ''
  Array.from(await supplierData).forEach(supplier => {
    html += renderSupplier(supplier)
  });

  $main.querySelector('.info__catalog').innerHTML = html
}

function buttonsHandler(event) {
  const $el = event.target

  switch ($el.dataset.click) {
    case 'openSupplier':
      hide($main)
      show($supplier)
      break
    case 'toMain':
      hide($supplier)
      show($main)

      show($sort)
      show($infoHeader)
      $info.style.width = '70%'

      hide(document.getElementById('tovarCatalog'))
      break
    case 'paramsSearch':
      const paramName = document.getElementById('paramName').value
      const paramRegion = document.getElementById('paramRegion').value
      renderSuppliers(`SELECT * FROM PROVIDERS WHERE name LIKE '%${paramName}%' AND region LIKE '%${paramRegion}%' ORDER BY id DESC`)
      break
    case 'globalSearch':
      const globalSearchInput = document.getElementById('globalSearchInput').value
      renderSuppliers(`SELECT * FROM PROVIDERS WHERE name LIKE '%${globalSearchInput}%' OR region LIKE '%${globalSearchInput}%' OR description LIKE '%${globalSearchInput}%' ORDER BY id DESC`)
      break
    case 'paramsClear':
      document.getElementById('paramName').value = ''
      document.getElementById('paramRegion').value = ''
      renderSuppliers(`SELECT * FROM PROVIDERS ORDER BY id DESC`)
      break
    case 'favorite':
      hide($sort)
      hide($infoHeader)
      $info.style.width = '100%'

      show($catalogBack)

      let idLine = ''

      if(localStorage.getItem('favorite')) {
        favorite = JSON.parse(localStorage.getItem('favorite'))

        favorite.forEach(fav => {
          // if(!fav) idLine += fav
          // else idLine += ',' . fav
          if(!idLine) {
            idLine += 'id = ' + fav
          } else {
            idLine += ' OR id = ' + fav
          }
        })
      }

      console.log(idLine)
      renderSuppliers(`SELECT * FROM PROVIDERS WHERE ${idLine} ORDER BY id DESC`)

      break
    case 'toFavorite':
      $el.textContent = '✅'

      let favorite
      if(localStorage.getItem('favorite')) {
        favorite = JSON.parse(localStorage.getItem('favorite'))
      } else {
        favorite = []
      }
      favorite.push($el.dataset.id)
      localStorage.setItem('favorite', JSON.stringify(favorite))
      break

    case 'sendMes':
      document.querySelector('#chat input').value = ''
      document.querySelector('#chat .chat__block span').classList.remove('hide')
      break

    case 'chatClose':
      hide($chat)
      break

    case 'chat':
      show($chat)
      break

    case 'openTovarCatalog':
      hide($main)
      show(document.getElementById('tovarCatalog'))
  }
}

function hide($el) {
  $el.classList.add('hide')
}

function show($el) {
  $el.classList.remove('hide')
}

async function sendQuery(body) {
  const $url = 'http://badger-residence.ru/hack/api/'

  try {
    const request = new Request($url, {
      method: 'post',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(body),
    })

    return await useRequest(request)
  } catch (error) {
    console.error(error)
  }
}
async function useRequest(request) {
  const response = await fetch(request)
  return await response.json()
}

var canvas = document.getElementById('myChart').getContext('2d');
canvas.width = 300;
canvas.height = 150;
var myChart = new Chart(canvas, {
    type: 'bar',
    data: {
        labels: ['Завод Агидель', 'Раменские смеси', 'ЛЗИД', 'ЭКО', 'Дёке Хоум Системс', 'Арсенал-групп'],
        datasets: [{
            label: 'руб./кг. Поставка материалов для строительства, ремонта и отделки',
            data: [142, 139, 120, 111, 102, 98],
            backgroundColor: [
                'rgba(255, 99, 132, 0.2)',
                'rgba(54, 162, 235, 0.2)',
                'rgba(255, 206, 86, 0.2)',
                'rgba(75, 192, 192, 0.2)',
                'rgba(153, 102, 255, 0.2)',
                'rgba(255, 159, 64, 0.2)'
            ],
            borderColor: [
                'rgba(255, 99, 132, 1)',
                'rgba(54, 162, 235, 1)',
                'rgba(255, 206, 86, 1)',
                'rgba(75, 192, 192, 1)',
                'rgba(153, 102, 255, 1)',
                'rgba(255, 159, 64, 1)'
            ],
            borderWidth: 1
        }]
    },
    options: {
        scales: {
            y: {
                beginAtZero: true
            }
        }
    }
});